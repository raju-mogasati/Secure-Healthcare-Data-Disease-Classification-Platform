import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";

function Home() {
    const location = useLocation();
    const navigate = useNavigate();
    const [user, setUser] = useState(location.state?.user);
    const [loading, setLoading] = useState(!user);

    useEffect(() => {   
        if (!user) {
            axios.get('http://localhost:3000/user', { withCredentials: true })
                .then(response => {
                    if (response.data.user) {
                        setUser(response.data.user);
                    } else {
                        navigate("/login");
                    }
                })
                .catch(() => navigate("/login"))
                .finally(() => setLoading(false));
        } else {
            setLoading(false);
        }
    }, [user, navigate]);

    return (
        <div style={{ textAlign: "center", padding: "20px" }}>
            <h1 style={{ color: "white", fontSize: "3rem" }}>Welcome Home {user && user.name} !!!</h1>
            
            {/* Clickable Feature Box */}
            <div 
                style={{
                    backgroundColor: "#333",
                    color: "white",
                    padding: "20px",
                    margin: "20px auto",
                    borderRadius: "10px",
                    width: "60%",
                    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
                    cursor: "pointer"
                }}
                onClick={() => navigate("/prediction")} // Navigate on click
            >
                <h2>Disease Prediction Feature</h2>
                <p>Click to start predicting diseases</p>
            </div>
        </div>
    );
}

export default Home;
