import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { Grid, Link, Button, Paper, TextField, Typography, MenuItem, Select, FormControl, InputLabel } from "@mui/material";

function SignUp() {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [role, setRole] = useState(""); // Role selection
    const navigate = useNavigate();

    const handleSignup = (e) => {
        e.preventDefault();
        axios.post("http://localhost:3000/Signup", { name, email, password, role })
            .then(result => {
                if (result.status === 201) {
                    alert("Signup successful! Please log in.");
                    navigate("/login"); // Redirect to login after signup
                }
            })
            .catch(err => {
                if (err.response && err.response.status === 400) {
                    window.alert("Email already exists. Please use a different email.");
                } else {
                    console.log(err);
                }
            });
    };

    const paperStyle = { padding: "2rem", margin: "100px auto", borderRadius: "1rem", boxShadow: "10px 10px 10px" };
    const heading = { fontSize: "2.5rem", fontWeight: "600" };
    const row = { display: "flex", marginTop: "2rem" };
    const btnStyle = { marginTop: "2rem", fontSize: "1.2rem", fontWeight: "700", backgroundColor: "blue", borderRadius: "0.5rem" };

    return (
        <Grid align="center" className="wrapper">
            <Paper style={paperStyle} sx={{ width: { xs: '80vw', sm: '50vw', md: '40vw', lg: '30vw', xl: '20vw' }, height: { lg: '60vh' } }}>
                <Typography component="h1" variant="h5" style={heading}>Signup</Typography>
                <form onSubmit={handleSignup}>
                    <TextField style={row} fullWidth type="text" label="Enter Name" name="name" onChange={(e) => setName(e.target.value)} />
                    <TextField style={row} fullWidth label="Email" type="email" placeholder="Enter Email" name="email" onChange={(e) => setEmail(e.target.value)} />
                    <TextField style={row} fullWidth label="Password" type="password" placeholder="Enter Password" name="password" onChange={(e) => setPassword(e.target.value)} />

                    {/* Role Selection Dropdown */}
                    <FormControl fullWidth style={row}>
                        <InputLabel>Select Role</InputLabel>
                        <Select value={role} onChange={(e) => setRole(e.target.value)}>
                            <MenuItem value="1">Doctor</MenuItem>
                            <MenuItem value="2">Patient</MenuItem>
                            <MenuItem value="3">Medical</MenuItem>
                        </Select>
                    </FormControl>

                    <Button style={btnStyle} variant="contained" type="submit">SignUp</Button>
                </form>
                <p>Already have an account? <Link href="/login">Login</Link></p>
            </Paper>
        </Grid>
    );
}

export default SignUp;
