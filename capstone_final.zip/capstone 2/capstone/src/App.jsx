import {React, useState, useEffect } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Home from "./components/Pat_Home";
import Login from "./components/Login";
import SignUp from "./components/Signup";
import { Navbar } from "./components/Navbar";
import Prediction from "./components/prediction"; // Ensure this component exists
// import ProtectedRoute from "./Components/ProtectedRoute";
import axios from "axios";

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
      axios.get('http://localhost:3000/user', { withCredentials: true })
          .then(response => {
              if (response.data.user) {
                  setIsLoggedIn(true);
              } else {
                  setIsLoggedIn(false);
              }
          })
          .catch(() => setIsLoggedIn(false));
  }, []);

  return (
      <div>
          <BrowserRouter>
              <Navbar isLoggedIn={isLoggedIn} setIsLoggedIn={setIsLoggedIn} />
              <Routes>
                  <Route path="/Pat_Home" element={<Home />} />
                  <Route path="/login" element={isLoggedIn ? <Navigate to="/Pat_Home" /> : <Login setIsLoggedIn={setIsLoggedIn} />} />
                  <Route path="/signup" element={isLoggedIn ? <Navigate to="/Pat_Home" /> : <SignUp setIsLoggedIn={setIsLoggedIn} />} />
                  <Route path="/" element={<Home />} />
                  <Route path="/prediction" element={<Prediction />} />
              </Routes>
          </BrowserRouter>
      </div>
  );
}

export default App;